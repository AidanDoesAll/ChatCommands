To install follow these steps. *If you dont follow these steps as instructed you may mess everything up*

1. First open up your server files then navigate to [gameplay] > chat > html 

2. Then grab the Config.js and place it inside of the html

3. When it says do you wish to replace these files click yes

4. Then restart you server

 If for some reson this does not work join the discord for help 
    Discord: https://discord.gg/VsCDBJFJgX 



Author: Aidan
8:23 PM 10/20/2021


