fx_version 'adamant'
game 'gta5'

client_script 'client.lua'
server_script 'config.lua'
server_script 'server.lua'

author 'Aidan'
description 'Basic chat commands for FiveM'