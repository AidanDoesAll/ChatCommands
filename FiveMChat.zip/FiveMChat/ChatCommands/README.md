# Commands
1. /twt {In game Twitter}
2. /fb {In game Facebook}
2. /VPN {In game VPN}
4. /do {Describes player actions}
5. /me {Players Actions}
6. /ooc {Out of character chat}
7. /calltow {In game Call Tow command}
8. /marketplace {Used to sell goods in game}

# Instalation
1. Open your server files then navigate to your resources folder
2. Place the folder (ChatCommands) inside of you resources folder
3. Then start it inside of your server.cfg
4. Then restart your server

# Need Help, Join the discord:https://discord.gg/VsCDBJFJgX