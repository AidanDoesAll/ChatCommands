Config = {}


-- Place you Discord WebHook Here
Config.discordwebhooklink = 'WEBHOOK_HERE' 


-- Set to true to enable
-- Set to false to disable
Config.twitter = true
Config.FB = true
Config.me = true
Config.doo = true
Config.VPN = true
Config.ooc = true
Config.calltow = true
Config.marketplace = true
Config.missingargs = "^1Please provide a message."